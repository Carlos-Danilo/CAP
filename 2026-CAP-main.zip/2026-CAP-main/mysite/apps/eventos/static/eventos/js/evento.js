document.addEventListener('DOMContentLoaded', function() {
    // Botões que fecham o modal
    const closeButtons = document.querySelectorAll('.modal-close');
    const cancelButtons = document.querySelectorAll('.btn-cancel');

    closeButtons.forEach(button => button.addEventListener('click', closeCreateModal));
    cancelButtons.forEach(button => button.addEventListener('click', closeCreateModal));
});
});
