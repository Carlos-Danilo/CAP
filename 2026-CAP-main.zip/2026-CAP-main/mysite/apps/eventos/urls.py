from django.urls import path
from .views import criar_evento, teste_modal

app_name = 'eventos'

urlpatterns = [
    path('criar/', criar_evento, name='criar_evento'),
    path('teste-modal/', teste_modal, name='teste_modal'),
]
