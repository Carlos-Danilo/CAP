from datetime import datetime

from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required

from apps.calendarios.models import Calendario
from apps.eventos.models import Evento


@login_required
def criar_evento(request):
    if request.method == 'POST':
        titulo = request.POST.get('titulo', '').strip()
        calendario_id = request.POST.get('calendario')
        data = request.POST.get('data')
        inicio = request.POST.get('inicio')
        fim = request.POST.get('fim')
        descricao = request.POST.get('descricao', '').strip()

        calendario = None
        if calendario_id:
            calendario = get_object_or_404(Calendario, pk=calendario_id)
        else:
            calendario = Calendario.objects.first()
            if calendario is None:
                calendario = Calendario.objects.create(
                    nome='Calendário padrão',
                    descricao='Calendário criado automaticamente para eventos',
                )

        if titulo and data and inicio and fim and calendario:
            try:
                inicio_dt = datetime.fromisoformat(f"{data}T{inicio}")
                fim_dt = datetime.fromisoformat(f"{data}T{fim}")
                evento = Evento(
                    nome=titulo,
                    conteudo=descricao,
                    inicio=inicio_dt,
                    fim=fim_dt,
                    calendario=calendario,
                )
                evento.full_clean()
                evento.save()
            except (ValueError, ValidationError):
                pass

        if calendario:
            return redirect('calendario', calendario.id)

    return redirect('inicio')


def teste_modal(request):
    return render(request, 'eventos/teste_modal.html', {})
